# `HopeSpeechDetection`
## My  work on hope speech detection task organized by dravidianlangtech.
In this tasks I have used various pretrained transformer models for transfer learning as well as cross lingual inferencing .
The dataset is pretty imbalanced .
The models used are:
i) IndicBERT
ii) mBERT-cased
iii) XLM-Roberta
iv) BERT-base-cased (English)
v) BERT-base-uncased (English)

